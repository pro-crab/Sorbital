import { useMemo, useRef, useState } from "react";

type Rating = 4 | 5;
type IconName =
  | "arrow"
  | "clipboard"
  | "clipboard-check"
  | "copy"
  | "external"
  | "refresh"
  | "star";

const reviewParts = {
  5: {
    openings: [
      "I had a genuinely lovely experience{place} from start to finish.",
      "My experience{place} was excellent from the moment I arrived.",
      "Everything about my visit{place} felt welcoming and well handled.",
      "I came away really impressed by my experience{place}.",
      "This was such a positive and enjoyable experience{place}.",
      "I had a wonderful time{place} and felt looked after throughout.",
      "My visit{place} was smooth, friendly, and genuinely enjoyable.",
      "I couldn't have asked for a better experience{place}.",
    ],
    service: [
      "The team was warm, attentive, and made the whole process feel effortless.",
      "Everyone I spoke with was friendly, thoughtful, and genuinely helpful.",
      "The service felt personal without ever being rushed or overdone.",
      "The team paid attention to the little details and made me feel welcome.",
      "Everything was handled with care, professionalism, and a friendly attitude.",
      "The people there were kind, knowledgeable, and happy to help.",
      "I really appreciated how easy and comfortable they made everything feel.",
      "There was a genuine level of care that stood out right away.",
    ],
    details: [
      "It is clear that they care about giving people a great experience.",
      "The quality and attention to detail really stood out to me.",
      "I left feeling valued, and that is not something you find everywhere.",
      "Nothing felt forced; it was simply thoughtful service done very well.",
      "The entire visit felt relaxed, organized, and easy from beginning to end.",
      "They created the kind of experience that makes you want to return.",
      "The atmosphere was pleasant and the service was consistently excellent.",
      "You can tell there is real pride behind what they do.",
    ],
    closings: [
      "I would happily recommend them.",
      "I will definitely be coming back.",
      "Highly recommended based on my experience.",
      "I am very glad I chose to visit.",
      "I would not hesitate to return.",
      "A well-deserved five stars from me.",
      "I would gladly recommend this place to others.",
      "Thank you for making the experience so enjoyable.",
    ],
  },
  4: {
    openings: [
      "I had a very good experience{place} overall.",
      "My visit{place} was positive from start to finish.",
      "I really enjoyed my experience{place}.",
      "Everything went smoothly during my visit{place}.",
      "I came away happy with the experience{place}.",
      "My time{place} was comfortable and enjoyable.",
      "I had a positive experience{place} and felt well looked after.",
      "This was a really good visit{place} overall.",
    ],
    service: [
      "The team was friendly, helpful, and easy to deal with.",
      "Everyone was welcoming and took the time to help when needed.",
      "The service was attentive and the whole process felt straightforward.",
      "The staff handled everything professionally and with a friendly attitude.",
      "I appreciated the helpful service and relaxed atmosphere.",
      "The team was approachable, polite, and clearly cared about the experience.",
      "Everything was handled efficiently without feeling rushed.",
      "The people there made the visit feel easy and comfortable.",
    ],
    details: [
      "The quality was strong and the little details were handled well.",
      "I appreciated the care and consistency throughout the visit.",
      "The experience felt organized, pleasant, and reliable.",
      "There was a lot to like, especially the helpful and personal service.",
      "I left feeling satisfied and pleased that I had chosen them.",
      "The overall experience was thoughtful and well put together.",
      "They made a good impression and delivered a quality experience.",
      "It was clear that the team takes pride in doing things properly.",
    ],
    closings: [
      "I would be happy to visit again.",
      "I would comfortably recommend them to others.",
      "A strong experience and well worth four stars.",
      "I am glad I gave this place a try.",
      "I would definitely consider returning.",
      "Overall, I would happily recommend this place.",
      "I look forward to visiting again in the future.",
      "Thanks to the team for a very positive experience.",
    ],
  },
} as const;

function Icon({ name, filled = false }: { name: IconName; filled?: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {name === "arrow" && <path d="M5 12h14m-5-5 5 5-5 5" />}
      {name === "copy" && (
        <>
          <rect x="8" y="8" width="11" height="11" rx="2" />
          <path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" />
        </>
      )}
      {name === "clipboard" && (
        <>
          <rect x="5" y="4" width="14" height="17" rx="2" />
          <path d="M9 4.5V3h6v1.5M9 10h6m-6 4h6" />
        </>
      )}
      {name === "clipboard-check" && (
        <>
          <rect x="5" y="4" width="14" height="17" rx="2" />
          <path d="M9 4.5V3h6v1.5m-6 9 2 2 4-4" />
        </>
      )}
      {name === "refresh" && (
        <>
          <path d="M20 7v5h-5" />
          <path d="M18.3 16A8 8 0 1 1 19 9l1 3" />
        </>
      )}
      {name === "external" && (
        <>
          <path d="M14 5h5v5m0-5-9 9" />
          <path d="M18 13v5a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5" />
        </>
      )}
      {name === "star" && (
        <polygon
          points="12 2.7 14.8 8.4 21 9.3 16.5 13.7 17.6 20 12 17 6.4 20 7.5 13.7 3 9.3 9.2 8.4"
          fill={filled ? "currentColor" : "none"}
        />
      )}
    </svg>
  );
}

function composeReview(rating: Rating, businessName: string, sequence: number) {
  const parts = reviewParts[rating];
  const place = businessName ? ` at ${businessName}` : "";
  const openingIndex = sequence % parts.openings.length;
  const serviceIndex = Math.floor(sequence / parts.openings.length) % parts.service.length;
  const detailIndex =
    Math.floor(sequence / (parts.openings.length * parts.service.length)) % parts.details.length;
  const closingIndex =
    Math.floor(
      sequence / (parts.openings.length * parts.service.length * parts.details.length),
    ) % parts.closings.length;

  return [
    parts.openings[openingIndex].replace("{place}", place),
    parts.service[serviceIndex],
    parts.details[detailIndex],
    parts.closings[closingIndex],
  ].join(" ");
}

function createReviewSeed() {
  if (window.crypto?.getRandomValues) {
    const value = new Uint32Array(1);
    window.crypto.getRandomValues(value);
    return value[0] % 4096;
  }
  return Math.floor(Math.random() * 4096);
}

function getPortalConfig() {
  const params = new URLSearchParams(window.location.search);
  const businessName = (params.get("business") ?? params.get("store") ?? "").trim().slice(0, 60);
  const placeId = params.get("placeId") ?? params.get("googlePlaceId");
  const viteEnv = (import.meta as ImportMeta & { env?: Record<string, string> }).env;
  const configuredUrl =
    params.get("reviewUrl") ?? params.get("ratingUrl") ?? viteEnv?.VITE_REVIEW_URL;

  if (placeId) {
    return {
      businessName,
      reviewUrl: `https://search.google.com/local/writereview?placeid=${encodeURIComponent(placeId)}`,
    };
  }

  if (configuredUrl) {
    try {
      const destination = new URL(configuredUrl, window.location.origin);
      if (destination.protocol === "http:" || destination.protocol === "https:") {
        return { businessName, reviewUrl: destination.href };
      }
    } catch {
      // Invalid destinations fall back to Google Maps rather than breaking the QR flow.
    }
  }

  return { businessName, reviewUrl: "https://www.google.com/maps" };
}

async function copyToClipboard(text: string) {
  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return;
    } catch {
      // The textarea fallback also works in browsers that block clipboard permissions.
    }
  }

  const textArea = document.createElement("textarea");
  textArea.value = text;
  textArea.style.position = "fixed";
  textArea.style.opacity = "0";
  document.body.appendChild(textArea);
  textArea.select();
  document.execCommand("copy");
  textArea.remove();
}

export default function App() {
  const portalConfig = useMemo(getPortalConfig, []);
  const initialSequence = useMemo(createReviewSeed, []);
  const generationCounts = useRef<Record<Rating, number>>({
    4: initialSequence + 1,
    5: initialSequence + 1,
  });
  const [rating, setRating] = useState<Rating>(5);
  const [review, setReview] = useState(() =>
    composeReview(5, portalConfig.businessName, initialSequence),
  );
  const [copied, setCopied] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const wordCount = useMemo(
    () => review.trim().split(/\s+/).filter(Boolean).length,
    [review],
  );

  const generateReview = (targetRating: Rating) => {
    const sequence = generationCounts.current[targetRating]++;
    setReview(composeReview(targetRating, portalConfig.businessName, sequence));
    setCopied(false);
  };

  const handleRating = (selectedStar: number) => {
    const nextRating: Rating = selectedStar === 5 ? 5 : 4;
    if (nextRating !== rating) {
      setRating(nextRating);
      generateReview(nextRating);
    }
  };

  const handleRewrite = () => generateReview(rating);

  const handleCopy = async () => {
    await copyToClipboard(review);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  const handleSubmit = async () => {
    await copyToClipboard(review);
    setCopied(true);
    setSubmitted(true);
    window.setTimeout(() => window.location.assign(portalConfig.reviewUrl), 450);
  };

  return (
    <main className="portal-shell">
      <div className="portal-tint" />
      <div className="top-glimpse" aria-hidden="true" />

      <div className="page-content">
        <section className="intro-panel reveal intro-reveal" aria-labelledby="page-title">
          <div className="step-kicker">
            <span />
            One last little step
          </div>
          <h1 id="page-title">
            Thanks for sharing
            <br />
            the <em>good stuff.</em>
          </h1>
          <p>
            We&apos;ve drafted a review based on your experience.
            <br className="wide-copy" /> Make it yours, copy it, and share the love-it only
            <br className="wide-copy" /> takes a moment.
          </p>
        </section>

        <section className="review-panel reveal review-reveal" aria-labelledby="review-heading">
          <div
            className="score-badge score-pop"
            key={rating}
            aria-label={`${rating.toFixed(1)} out of 5 stars`}
          >
            {rating.toFixed(1)}
          </div>

          <div className="rating-row">
            <h2 id="review-heading">Your review</h2>
            <div className="stars" aria-label="Choose a 4 or 5 star rating">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  type="button"
                  key={star}
                  onClick={() => handleRating(star)}
                  aria-label={
                    star < 4
                      ? `${star} stars selects the 4 star minimum`
                      : `Rate ${star} stars`
                  }
                >
                  <Icon name="star" filled={star <= rating} />
                </button>
              ))}
            </div>
          </div>
          <p className="edit-note">Feel free to edit it before you copy.</p>

          <div className="review-field">
            <span className="quote-mark" aria-hidden="true">
              &ldquo;
            </span>
            <textarea
              value={review}
              onChange={(event) => {
                setReview(event.target.value);
                setCopied(false);
              }}
              aria-label="Your review text"
              spellCheck="true"
            />
            <span className="word-count">{wordCount} words</span>
          </div>

          <div className="review-actions">
            <button
              type="button"
              className="rewrite-button"
              onClick={handleRewrite}
            >
              <Icon name="refresh" />
              Rewrite
            </button>
            <button
              type="button"
              className={`copy-button ${copied ? "is-copied" : ""}`}
              onClick={handleCopy}
            >
              <Icon name={copied ? "clipboard-check" : "copy"} />
              {copied ? "Copied" : "Copy review"}
            </button>
          </div>

          <div className="soft-divider" />

          <button
            type="button"
            className={`submit-button ${submitted ? "is-submitted" : ""}`}
            onClick={handleSubmit}
          >
            {submitted ? "Ready to post" : "Submit rating"}
            <Icon name={submitted ? "clipboard-check" : "arrow"} />
          </button>
          <p className="redirect-note" role="status" aria-live="polite">
            {submitted
              ? "Review copied. Opening the rating portal..."
              : "You'll be redirected to the rating portal to post your review."}
          </p>
        </section>

        <section className="steps-panel reveal steps-reveal" aria-labelledby="steps-title">
          <h2 id="steps-title">Share in 3 quick steps</h2>
          <div className="steps-list">
            <div className="step-item">
              <span className="step-icon">
                <Icon name="copy" />
                <b>1</b>
              </span>
              <span>Copy it</span>
            </div>
            <span className="connector" aria-hidden="true" />
            <div className="step-item">
              <span className="step-icon">
                <Icon name="clipboard" />
                <b>2</b>
              </span>
              <span>Paste on review page</span>
            </div>
            <span className="connector" aria-hidden="true" />
            <div className="step-item">
              <span className="step-icon">
                <Icon name="external" />
                <b>3</b>
              </span>
              <span>Post it</span>
            </div>
          </div>
        </section>
      </div>

    </main>
  );
}
